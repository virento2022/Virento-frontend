import React from "react"

const SingleRequestCard = (props) => {
    return (
        <p>You have a notification from {props.title}</p>
    )
}

export default SingleRequestCard;