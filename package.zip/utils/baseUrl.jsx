const baseUrl = "https://virento-backend.herokuapp.com";

export default baseUrl;
