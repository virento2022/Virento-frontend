"use strict";
(() => {
var exports = {};
exports.id = 936;
exports.ids = [936];
exports.modules = {

/***/ 6024:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _auth0_)
});

;// CONCATENATED MODULE: external "@auth0/nextjs-auth0"
const nextjs_auth0_namespaceObject = require("@auth0/nextjs-auth0");
;// CONCATENATED MODULE: ./pages/api/auth/[...auth0].js

/* harmony default export */ const _auth0_ = ((0,nextjs_auth0_namespaceObject.handleAuth)()); // handleAuth will create routes:
 // /api/auth/login
 // /api/auth/logout
 // /api/auth/callback
 // /api/auth/me


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(6024));
module.exports = __webpack_exports__;

})();